<template>
    <div class="m-container" id="collection">
            <div class="row">
                <div class="sidebar-left col-md-3">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <router-link :to="{name:'men'}" class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                               Mens
                            </router-link>
                        </li>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#collection">
                            <div class="ml-2">
                                <li>watches</li>
                                <li>t-shirts</li>
                                <li>pants</li>
                                <li>suits</li>
                                <li>shoes</li>
                            </div>
                        </div>
                        <li class="list-group-item">
                            <router-link  :to="{name:'women'}" class="btn btn-link" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapseOne">
                                Women
                            </router-link>
                        </li>
                        <div id="collapsetwo" class="collapse show" aria-labelledby="headingOne" data-parent="#collection">
                            <div class="ml-2">
                                <li>watches</li>
                                <li>t-shirts</li>
                                <li>pants</li>
                                <li>suits</li>
                                <li>shoes</li>
                            </div>
                        </div>

                    </ul>
                </div>
                <div class="col-md-8">
                    <router-view>
                    </router-view>
                </div>
            </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('second Component mounted.')
        },
        methods: {
            getPath(image) {
                return "http://0.0.0.0:81/myproject/public/images/" + image;
            },
        },
    }
</script>
