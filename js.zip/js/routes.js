
import HomeComponent from './home';
import secondComponent from './components/SecondComponent.vue';


import VueRouter from 'vue-router';
import MenComponent from "./components/MenComponent";
import WomenComponent from "./components/WomenComponent";
import CollectionComponent from "./components/CollectionComponent";

const routes =[
    {
        path:'/',
        name:'home',
        component:HomeComponent
    }, {
        path:'/collection',
        component:secondComponent,
        children:[
            {
                path:'',
                name:'collections',
                Component:CollectionComponent
            },
            {
            name:'men',
            path:'men',
            component:MenComponent
        },
            {
                name:'women',
                path:'women',
                component:WomenComponent
            },
            ]
    },

];
const router =new VueRouter({
    routes,
});

export default router ;
