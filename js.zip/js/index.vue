<template>
    <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Fashion Rent</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <router-link class="navbar-brand" :to="{name:'home'}">Home</router-link>
                <li class="nav-item">
                <router-link class="btn nav-button"   :to="{name:'collections'}">Second</router-link>
                </li>
                <li class="nav-item float-right">
                    <a class="nav-link" href="#">Login</a>

                </li>
            </ul>
        </div>
    </nav>

        <div class="">
            <router-view></router-view>
        </div>

    </div>
</template>

<script>
export default {
    name: "home"
}
</script>

<style scoped>

</style>
