
<template>
    <div>
        <div
            id="carouselExampleCaptions"
            class="carousel slide"
            data-ride="carousel"
        >

            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img
                        :src="getPath('first.jpg')"
                        class="d-block w-100"
                        style="height: 850px"
                        alt="..."
                    />
                    <div class="carousel-caption d-none d-md-block" style="color: #000">
                        <h2>First slide label</h2>
                        <p>Some representative placeholder content for the first slide.</p>
                    </div>
                </div>

            </div>



        </div>
        <!-- start of for her and him -->
        <div>
            <div class="row mt-4 d-flex justify-content-center">
                <div class="col-md-5 for">
                    <img class="img-fluid" :src="getPath('forher.jpg')" alt="" srcset="" />
                    <div class="hero-text">
                        <p style="font-size: 50px">FOR HER</p>
                    </div>
                </div>

                <div class="col-md-5 for">
                    <img :src="getPath('forhim.jpg')" alt="" srcset="" />
                    <div class="hero-text">
                        <p style="font-size: 50px">FOR HIM</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end of for her and him -->

        <!-- start of Purpose of site -->

        <div class="purpose">
            <div class="row d-flex justify-content-center">
                <div class="col-md-3 t-center">
          <span style="font-size: 35px">
            <font-awesome-icon :icon="['fas', 'hand-point-up']"
            /></span>
                    <h3>1- Make Your Best Choice</h3>
                    <p>
                        Browse through our exclusive collection and pick an outfit to lease
                        with ease.
                    </p>
                </div>

                <div class="col-md-3 t-center">
          <span style="font-size: 35px">
            <font-awesome-icon :icon="['fas', 'tshirt']"
            /></span>
                    <h3>2- Your Dream Fit</h3>
                    <p>
                        Select your size, the preferred duration and the date of delivery.
                    </p>
                </div>

                <div class="col-md-3 t-center">
          <span style="font-size: 35px">
            <font-awesome-icon :icon="['fas', 'check']"
            /></span>
                    <h3>3- Select Your Style</h3>
                    <p>
                        Amp up your game with accessories from our specially curated
                        collection to complement your look.
                    </p>
                </div>
            </div>
            <div class="row d-flex justify-content-center mt-4">
                <div class="col-md-3 t-center">
          <span style="font-size: 35px">
            <font-awesome-icon :icon="['fas', 'phone']"
            /></span>
                    <h3>4- Easy To Communicate</h3>
                    <p>The Best Way To Communicate With Your Renter</p>
                </div>
                <div class="col-md-3 t-center">
          <span style="font-size: 35px">
            <font-awesome-icon :icon="['fas', 'hand-point-up']"
            /></span>
                    <h3>5- make your bestchoice</h3>
                    <p>
                        Browse through our exclusive collection and pick an outfit to lease
                        with ease.
                    </p>
                </div>
            </div>
        </div>

        <!-- end of Purpose of site -->


        <!-- start of latest of site -->

        <div class="latest mt-5">
            <div class="row">
                <div class="col-md-6">

                    <div class="t-center mb-3">
                        <p > Wow Arrival</p>
                        <h2>Latest Products</h2>
                        <p >Get Spring ready in the freshest looks of the season</p>
                        <button class="btn btn-secondary" >Rent Now</button>
                    </div>

                    <div class="row">
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('modal.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('modal.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('modal.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <img class="img-fluid" :src="getPath('modal.jpg')" alt="" />
                </div>
            </div>
        </div>
        <!-- end of latest of site -->

        <!-- start of banner -->
        <div class="banner mt-5">
            <div class="row d-flex justify-content-center">
                <div class="col-md-4">
                    <img
                        class="float-left"
                        style="height: 300px"
                        :src="getPath('ban1.png')"
                        alt=""
                        srcset=""
                    />
                </div>

                <div class="col-md-4 my-auto t-center">
                    <h1> Fashion On Rent</h1>
                    <p>The Best Place To Rent Your Outfits</p>
                </div>
                <div class="col-md-4">
                    <img
                        class="float-right"
                        style="height: 300px"
                        :src="getPath('ban2.png')"
                        alt=""
                        srcset=""
                    />
                </div>
            </div>

        </div>
        <!-- end Of banner -->

        <!-- start of men's wears -->
        <div class="latest mt-5">
            <div class="row">
                <div class="col-md-6">

                    <div class="t-center mb-3">
                        <p >MEN'S WEAR</p>
                        <h2>Why Not Men Also rent Everything</h2>
                        <p >For The Stylished Men</p>
                        <button class="btn btn-secondary" >Rent Now</button>
                    </div>

                    <div class="row">
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('man.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('man.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                        <div class="col-md-4 l-product t-center">
                            <img
                                style="height: 300px"
                                :src="getPath('man.png')"
                                alt=""
                                srcset=""
                            />
                            <p style="font-size: 20px">black dess with flowers</p>
                            <span> 150 $</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <img class="img-fluid" :src="getPath('man.jpg')" alt="" />
                </div>
            </div>
        </div>
        <!-- end of men's wear -->



        <!-- start Of Footer -->
        <section class="mt-5">
            <!-- Footer -->
            <footer class="text-center text-white" style="background-color:#232737;">
                <!-- Grid container -->
                <div class="container p-4 pb-0">
                    <!-- Section: CTA -->
                    <section class="">
                        <p class="d-flex justify-content-center align-items-center">
                            <span class="mr-2">Register for free </span>
                            <button type="button" class="btn btn-outline-light btn-rounded">
                                Sign up!
                            </button>
                        </p>
                    </section>
                    <!-- Section: CTA -->
                </div>
                <!-- Grid container -->

                <!-- Copyright -->
                <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
                    © 2020 Copyright:
                    <a class="text-white" href="">FashionRent.com</a>
                </div>
                <!-- Copyright -->
            </footer>
            <!-- Footer -->
        </section>

        <!-- end Of Footer -->

    </div>
</template>
<script>
export default {
    name: "home",
    data() {
        return {
            image1: "/images/first.jpg",
        };
    },
    mounted() {},
    methods: {
        getPath(image) {
            return "http://0.0.0.0:81/myproject/public/images/" + image;
        },
    },
};
</script>
